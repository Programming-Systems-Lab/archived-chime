This is the Crystal Space Demo. To use this demo you need the very latest
version of CS (straight from CVS, 0.18 is not recent enough!). Make sure you
compile everything (at least 'make walkall engine demo').
Then put demodata.zip (UNEXTRACTED) in 'data' (alternatively you can also
extract demodata.zip and put the contents in 'data/demodata').

To start the demo type 'csdemo'. It is recommended to run this demo with
accelerated OpenGL as this looks a LOT better (csdemo -video=opengl).


Special note for MingW (free gcc compiler on Windows). Due to a bug in dllwrap
(which is used in MingW for creating the dll's) the engine plugin needs to
be compiled in a special way. First do 'make engine' if you didn't already do
that. After that use the following command to remake engine.dll:

	dllwrap -q -s --no-export-all-symbols --dllname engine -o engine.dll
	out/WIN32/X86/optimize/enginep.o out/WIN32/X86/optimize/engine.o
	-lcsengine -lcsutil -lcssys_D -lcsgeom -lcsobject -lcsutil -lcssys_D
	-lpng -lz  -s -Lout/WIN32/X86/optimize/ -mwindows -mconsole

Replace 'optimize' with 'debug' if you compiled debug.


For more information about Crystal Space check out:
	http://crystal.linuxgames.com
	http://crystal.sourceforge.net
Or mail:
	jorrit.tyberghein@uz.kuleuven.ac.be
	jorrit.tyberghein@pandora.be
